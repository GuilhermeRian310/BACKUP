<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classe : 2D</title>
    <link rel="stylesheet" href="STYLEF.css">
    <script src="8.js" defer></script>
</head>
<body>
    <header>
        <button onclick="window.history.back()">Voltar</button>
        <div id="tools">
            <h1 id="Class-form-Title">Chamada</h1>
            <h1><p style="font-size: 4vh; margin-top: 10vh;">Data : <strong class="data-atual"><?php echo date('d/m/Y'); ?></strong></p></h1>
        </div>
    </header>
    <nav>
        <div id="article-container">
            <button id="edit-button">EDITAR</button>
            <button id="add-button" style="font-size: 2.3vh;">ADICIONAR</button>
            <button id="freq-button" style="font-size: 2vh;" onclick="window.location.href='Frequencia.php'">FREQUÊNCIA</button>
            <button id="save-button">SALVAR</button>
        </div>
    </nav>
    <article>
        <div id="Class-Form-base">
            <div id="base-Form">
                <table border="7">
                    <thead>
                        <tr>
                            <th>Número</th>
                            <th id="nome">Nome</th>
                            <th colspan="9" id="freq">Frequencias</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </article>
</body>
</html>