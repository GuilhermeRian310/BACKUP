function atualizarNumeracao() {
    const linhas = document.querySelectorAll('.alunos');
    linhas.forEach((linha, index) => {
        const inputNumero = linha.querySelector('.numero');
        if (inputNumero) {
            inputNumero.value = index + 1; // O primeiro aluno (index 0) vira número 1
            inputNumero.disabled = true;   // Garante que o campo comece ou continue bloqueado
        }
    });
}

document.getElementById('edit-button').addEventListener('click', function() {
    const btnAdicionar = document.getElementById('add-button');
    const alunos = document.querySelectorAll('.alunos');
    
    // Verifica se o botão adicionar NÃO está desabilitado (ou seja, está ativo)
    if (!btnAdicionar.disabled) {
        // --- ENTRA NO MODO DE EDIÇÃO ---
        
        // 1. Desabilita o botão de adicionar e muda o visual
        btnAdicionar.disabled = true;
        btnAdicionar.style.backgroundColor = '#555555'; 
        btnAdicionar.style.cursor = 'not-allowed'; 
        
        // 2. Ativa os campos de número e nome de todas as linhas
        alunos.forEach(aluno => {
            aluno.querySelector('.numero').removeAttribute('disabled');
            aluno.querySelector('.nome_com').removeAttribute('disabled');
        });
        
    } else {
        // --- SAI DO MODO DE EDIÇÃO (SALVA / BLOQUEIA) ---
        
        // 1. Reativa o botão de adicionar e volta o visual padrão
        btnAdicionar.disabled = false;
        btnAdicionar.style.backgroundColor = ''; // Remove o estilo inline e volta ao CSS padrão
        btnAdicionar.style.cursor = 'pointer'; 
        
        // 2. Desabilita os campos de número e nome novamente
        alunos.forEach(aluno => {
            aluno.querySelector('.numero').setAttribute('disabled', 'true');
            aluno.querySelector('.nome_com').setAttribute('disabled', 'true');
        });
        
    }
});

document.getElementById('add-button').addEventListener('click', function() {
    const tbody = document.querySelector('tbody');
    const novaLinha = document.createElement('tr');
    novaLinha.classList.add('alunos');
    novaLinha.innerHTML = `
        <td><input type="text" class="numero" value="1" disabled></td>
        <td><input type="text" class="nome_com" value="Nome do Aluno" disabled></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td><button class="btn-apagar">X</button></td>
    `;
    tbody.appendChild(novaLinha);

    atualizarNumeracao(); // Atualiza a numeração de todas as linhas, incluindo a nova
    
    // 1. Ativa os campos e adiciona o evento de clique para as imagens
    novaLinha.querySelectorAll('.freq img').forEach(img => {
        img.addEventListener('click', function() {
            const td = img.parentElement; 

            if (img.src.includes('sim.png')) {
                img.src = 'just.png';
                td.style.backgroundColor = '#7c5c2b'; 
            } else if (img.src.includes('just.png')) {
                img.src = 'nao.png';
                td.style.backgroundColor = '#6c2d34'; 
            } else {
                img.src = 'sim.png';
                td.style.backgroundColor = '#205822'; 
            }
        });
    });

    // 2. ADICIONADO AQUI: Evento de apagar exclusivo para ESTA nova linha
    novaLinha.querySelector('.btn-apagar').addEventListener('click', function() {
        if (confirm('Tem certeza que deseja apagar esta linha?')) {
            novaLinha.remove(); // Remove diretamente a linha criada
            alert('Linha apagada com sucesso!');
            atualizarNumeracao(); // Atualiza a numeração das linhas restantes
        }
    });
});

document.getElementById('save-button').addEventListener('click', function() {
    const linhas = document.querySelectorAll('.alunos');
    if (linhas.length === 0) {
        alert("Adicione pelo menos um aluno antes de salvar.");
        return;
    }

    const payload = { alunos: [] };

    linhas.forEach(linha => {
        const numero = linha.querySelector('.numero').value;
        const nome = linha.querySelector('.nome_com').value;
        
        // Coleta o status de imagem de cada um dos 9 períodos (sim, nao, just)
        const frequencias = [];
        linha.querySelectorAll('.freq img').forEach(img => {
            if (img.src.includes('sim.png')) frequencias.push('presente');
            else if (img.src.includes('just.png')) frequencias.push('justificado');
            else frequencias.push('ausente');
        });

        payload.alunos.push({
            numero: numero,
            nome: nome,
            frequencias: frequencias
        });
    });

    // Envia os dados estruturados para o arquivo PHP via Fetch API
    fetch('salvar_chamada.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            alert(data.message);
        } else {
            alert('Erro: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Erro de comunicação com o servidor.');
    });
});