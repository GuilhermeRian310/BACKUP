<?php
// buscar_chamada.php
header('Content-Type: application/json; charset=utf-8');

try {
    // IMPORTANTE: Mude 'seu_banco' para o nome correto do seu banco de dados
    $pdo = new PDO('mysql:host=localhost;dbname=sistema_chamada;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Pega a data passada pela URL ou usa a data de hoje caso não venha nenhuma
    $data = isset($_GET['data']) ? $_GET['data'] : date('Y-m-d');

    // Faz o SELECT buscando o número, nome e todas as 9 aulas de frequência
    $sql = "SELECT a.id, a.numero, a.nome, 
               f.f1, f.f2, f.f3, f.f4, f.f5, f.f6, f.f7, f.f8, f.f9
        FROM alunos a
        LEFT JOIN frequencias f ON a.id = f.aluno_id AND f.data_registro = :data
        ORDER BY a.numero ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['data' => $data]);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($resultados);

} catch (PDOException $e) {
    echo json_encode(["erro" => $e->getMessage()]);
}
?>