<?php
header("Content-Type: application/json");
$host = "localhost";
$user = "root"; // Altere se necessário
$pass = "";     // Altere se necessário
$db   = "sistema_chamada";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Erro de conexão: " . $e->getMessage()]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['alunos'])) {
    echo json_encode(["status" => "error", "message" => "Dados inválidos."]);
    exit;
}

$dataAtual = date('Y-m-d');
$horarioAtual = date('H:i:s');

try {
    $pdo->beginTransaction();

    foreach ($data['alunos'] as $alunoData) {
        $numero = $alunoData['numero'];
        $nome = $alunoData['nome'];
        $freqs = $alunoData['frequencias']; // Array com 9 posições

        // 1. Verifica ou insere o aluno pelo número/nome
        $stmt = $pdo->prepare("SELECT id FROM alunos WHERE nome = ?");
        $stmt->execute([$nome]);
        $aluno = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($aluno) {
            $alunoId = $aluno['id'];
            // Atualiza o número caso tenha mudado na ordenação
            $stmtUpdate = $pdo->prepare("UPDATE alunos SET numero = ? WHERE id = ?");
            $stmtUpdate->execute([$numero, $alunoId]);
        } else {
            $stmtIns = $pdo->prepare("INSERT INTO alunos (numero, nome) VALUES (?, ?)");
            $stmtIns->execute([$numero, $nome]);
            $alunoId = $pdo->lastInsertId();
        }

        // 2. Verifica se já existe frequência deste aluno hoje
        $stmtCheckFreq = $pdo->prepare("SELECT id FROM frequencias WHERE aluno_id = ? AND data_registro = ?");
        $stmtCheckFreq->execute([$alunoId, $dataAtual]);
        $freqExistente = $stmtCheckFreq->fetch(PDO::FETCH_ASSOC);

        if ($freqExistente) {
            // Atualiza frequência de hoje
            $sqlFreq = "UPDATE frequencias SET f1=?, f2=?, f3=?, f4=?, f5=?, f6=?, f7=?, f8=?, f9=?, horario=? WHERE id=?";
            $params = array_merge($freqs, [$horarioAtual, $freqExistente['id']]);
            $pdo->prepare($sqlFreq)->execute($params);
        } else {
            // Insere nova frequência
            $sqlFreq = "INSERT INTO frequencias (aluno_id, data_registro, f1, f2, f3, f4, f5, f6, f7, f8, f9, horario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $params = array_merge([$alunoId, $dataAtual], $freqs, [$horarioAtual]);
            $pdo->prepare($sqlFreq)->execute($params);
        }
    }

    $pdo->commit();
    echo json_encode(["status" => "success", "message" => "Chamada salva com sucesso!"]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(["status" => "error", "message" => "Erro ao salvar: " . $e->getMessage()]);
}
?>