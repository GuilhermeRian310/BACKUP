function atualizarNumeracao() {
    const linhas = document.querySelectorAll('.alunos');
    linhas.forEach((linha, index) => {
        const inputNumero = linha.querySelector('.numero');
        if (inputNumero) {
            inputNumero.value = index + 1; // O primeiro aluno (index 0) vira número 1
            inputNumero.disabled = true;   // Garante que o campo comece ou continue bloqueado
        }
    });
}

document.getElementById('edit-button').addEventListener('click', function() {
    const btnAdicionar = document.getElementById('add-button');
    const alunos = document.querySelectorAll('.alunos');
    
    // Verifica se o botão adicionar NÃO está desabilitado (ou seja, está ativo)
    if (!btnAdicionar.disabled) {
        // --- ENTRA NO MODO DE EDIÇÃO ---
        
        // 1. Desabilita o botão de adicionar e muda o visual
        btnAdicionar.disabled = true;
        btnAdicionar.style.backgroundColor = '#555555'; 
        btnAdicionar.style.cursor = 'not-allowed'; 
        
        // 2. Ativa os campos de número e nome de todas as linhas
        alunos.forEach(aluno => {
            aluno.querySelector('.numero').removeAttribute('disabled');
            aluno.querySelector('.nome_com').removeAttribute('disabled');
        });
        
    } else {
        // --- SAI DO MODO DE EDIÇÃO (SALVA / BLOQUEIA) ---
        
        // 1. Reativa o botão de adicionar e volta o visual padrão
        btnAdicionar.disabled = false;
        btnAdicionar.style.backgroundColor = ''; // Remove o estilo inline e volta ao CSS padrão
        btnAdicionar.style.cursor = 'pointer'; 
        
        // 2. Desabilita os campos de número e nome novamente
        alunos.forEach(aluno => {
            aluno.querySelector('.numero').setAttribute('disabled', 'true');
            aluno.querySelector('.nome_com').setAttribute('disabled', 'true');
        });
        
    }
});

// Pegar parâmetro 'data' da URL (?data=2026-06-15)
const urlParams = new URLSearchParams(window.location.search);
const dataChamada = urlParams.get('data') || '';

// 1. FUNÇÃO CORRIGIDA: Trata maiúsculas, minúsculas e valores nulos/vazios do SQL
function obterEstiloStatus(status) {
    // Se o status for nulo ou indefinido, transforma em string vazia
    if (!status) status = '';
    
    // Remove espaços em branco e padroniza para letras minúsculas
    status = status.trim().toLowerCase();

    if (status === 'sim' || status === 'p' || status === 'presente') {
        return { src: 'sim.png', bg: '#205822' }; // Verde
    }
    if (status === 'just' || status === 'j' || status === 'justificad') {
        return { src: 'just.png', bg: '#7c5c2b' }; // Laranja/Marrom
    }
    
    // Se for 'nao', 'f', 'falta' ou estiver vazio, carrega o vermelho
    return { src: 'nao.png', bg: '#6c2d34' }; 
}


// 1. Função atualizada para receber o ID do aluno
function adicionarLinhaChamada(id, numero, nome, frequencias) {
    const tbody = document.querySelector('tbody');
    const novaLinha = document.createElement('tr');
    novaLinha.classList.add('alunos');
    
    // Guardamos o ID do banco de dados na própria linha do HTML (invisível para o usuário)
    novaLinha.setAttribute('data-id', id);
    
    let colunasFreqHTML = '';
    for (let i = 1; i <= 9; i++) {
        const statusAula = frequencias[`f${i}`];
        const estilo = obterEstiloStatus(statusAula); 
        colunasFreqHTML += `<td class="freq" style="background-color: ${estilo.bg};"><img src="${estilo.src}" class="img-freq" style="cursor: pointer;"></td>`;
    }

    novaLinha.innerHTML = `
        <td><input type="text" class="numero" value="${numero}" disabled></td>
        <td><input type="text" class="nome_com" value="${nome}" disabled></td>
        ${colunasFreqHTML}
        <td><button class="btn-apagar">X</button></td>
    `;
    
    tbody.appendChild(novaLinha);

    // [Seu evento de clique nas imagens continua igual aqui]
    novaLinha.querySelectorAll('.freq img').forEach(img => {
        img.addEventListener('click', function() {
            const td = img.parentElement; 
            const srcAtual = img.getAttribute('src');
            if (srcAtual === 'sim.png') {
                img.setAttribute('src', 'just.png');
                td.style.backgroundColor = '#7c5c2b';
            } else if (srcAtual === 'just.png') {
                img.setAttribute('src', 'nao.png');
                td.style.backgroundColor = '#6c2d34';
            } else {
                img.setAttribute('src', 'sim.png');
                td.style.backgroundColor = '#205822';
            }
        });
    });

    // MODIFICADO: Evento de apagar integrado com o Banco de Dados
    novaLinha.querySelector('.btn-apagar').addEventListener('click', function() {
        if (confirm('Tem certeza que deseja apagar este aluno permanentemente do sistema e do banco de dados?')) {
            
            // Cria os dados para enviar para o PHP
            const formData = new FormData();
            formData.append('id', id);

            // Avisa o servidor para deletar no SQL
            fetch('deletar_aluno.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(resposta => {
                if (resposta.sucesso) {
                    // Se o PHP deletou com sucesso no banco, removemos a linha da tela
                    novaLinha.remove(); 
                    if (typeof atualizarNumeracao === "function") atualizarNumeracao();
                    alert('Aluno apagado do banco de dados com sucesso!');
                } else {
                    alert('Erro ao apagar no banco de dados: ' + resposta.erro);
                }
            })
            .catch(error => console.error('Erro na requisição de deletar:', error));
        }
    });
}

// 2. Carregamento atualizado para passar o ID do aluno para a função
window.addEventListener('DOMContentLoaded', function() {
    fetch(`buscar_chamada.php?data=${dataChamada}`)
        .then(response => response.json())
        .then(alunos => {
            if (alunos.erro) {
                console.error('Erro no SQL:', alunos.erro);
                return;
            }

            alunos.forEach(aluno => {
                const statusFrequencias = {
                    f1: aluno.f1, f2: aluno.f2, f3: aluno.f3,
                    f4: aluno.f4, f5: aluno.f5, f6: aluno.f6,
                    f7: aluno.f7, f8: aluno.f8, f9: aluno.f9
                };
                
                // PASSANDO O ID AQUI: aluno.id adicionado como primeiro parâmetro
                adicionarLinhaChamada(aluno.id, aluno.numero, aluno.nome, statusFrequencias);
            });
        })
        .catch(error => console.error('Erro ao processar dados:', error));
});

// Função auxiliar para criar a linha na tabela (reutilizada pelo banco e pelo botão Add)
function adicionarLinhaNaTabela(numero = '', nome = '') {
    const tbody = document.querySelector('tbody');
    const novaLinha = document.createElement('tr');
    novaLinha.classList.add('alunos');
    
    novaLinha.innerHTML = `
        <td><input type="text" class="numero" name="numero" value="${numero}" disabled></td>
        <td><input type="text" class="nome_com" name="nome" value="${nome}" disabled></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td class="freq"><img src="nao.png" class="img-freq" style="cursor: pointer;"></td>
        <td><button class="btn-apagar">X</button></td>
    `;
    tbody.appendChild(novaLinha);

    // Reativa os eventos das imagens de frequência nesta nova linha
    novaLinha.querySelectorAll('.freq img').forEach(img => {
        img.addEventListener('click', function() {
            const td = img.parentElement; 
            if (img.src.includes('sim.png')) {
                img.src = 'just.png';
                td.style.backgroundColor = '#7c5c2b'; 
            } else if (img.src.includes('just.png')) {
                img.src = 'nao.png';
                td.style.backgroundColor = '#6c2d34'; 
            } else {
                img.src = 'sim.png';
                td.style.backgroundColor = '#205822'; 
            }
        });
    });

    // Reativa o evento do botão apagar nesta nova linha
    novaLinha.querySelector('.btn-apagar').addEventListener('click', function() {
        if (confirm('Tem certeza que deseja apagar esta linha?')) {
            novaLinha.remove(); 
            atualizarNumeracao(); // Seus números organizados
            alert('Linha apagada com sucesso!');
        }
    });
}

document.getElementById('add-button').addEventListener('click', function() {
    // Cria uma linha em branco para o usuário digitar um novo aluno manualmente
    adicionarLinhaNaTabela('', '');
    atualizarNumeracao();
});

document.getElementById('save-button').addEventListener('click', function() {
    const linhas = document.querySelectorAll('.alunos');
    if (linhas.length === 0) {
        alert("Adicione pelo menos um aluno antes de salvar.");
        return;
    }

    const payload = { alunos: [] };

    linhas.forEach(linha => {
        const numero = linha.querySelector('.numero').value;
        const nome = linha.querySelector('.nome_com').value;
        
        // Coleta o status de imagem de cada um dos 9 períodos (sim, nao, just)
        const frequencias = [];
        linha.querySelectorAll('.freq img').forEach(img => {
            if (img.src.includes('sim.png')) frequencias.push('presente');
            else if (img.src.includes('just.png')) frequencias.push('justificado');
            else frequencias.push('ausente');
        });

        payload.alunos.push({
            numero: numero,
            nome: nome,
            frequencias: frequencias
        });
    });

    // Envia os dados estruturados para o arquivo PHP via Fetch API
    fetch('salvar_chamada.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            alert(data.message);
        } else {
            alert('Erro: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Erro de comunicação com o servidor.');
    });
});