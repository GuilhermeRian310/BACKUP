<?php
// deletar_aluno.php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Mude 'seu_banco' para o nome correto do seu banco de dados
        $pdo = new PDO('mysql:host=localhost;dbname=sistema_chamada;charset=utf8', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Pega o ID enviado pelo JavaScript
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

        if ($id > 0) {
            // 1. Primeiro deleta as frequências vinculadas a esse aluno (evita erro de chave estrangeira)
            $stmtFreq = $pdo->prepare("DELETE FROM frequencias WHERE aluno_id = :id");
            $stmtFreq->execute(['id' => $id]);

            // 2. Depois deleta o aluno da tabela de alunos
            $stmtAluno = $pdo->prepare("DELETE FROM alunos WHERE id = :id");
            $stmtAluno->execute(['id' => $id]);

            echo json_encode(["sucesso" => true]);
        } else {
            echo json_encode(["sucesso" => false, "erro" => "ID inválido."]);
        }

    } catch (PDOException $e) {
        echo json_encode(["sucesso" => false, "erro" => $e->getMessage()]);
    }
}
?>