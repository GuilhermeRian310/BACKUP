<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "sistema_chamada";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro de conexão: " . $e->getMessage());
}

// Busca os dias distintos que possuem frequências registradas
$stmt = $pdo->query("SELECT data_registro, MAX(horario) as ultimo_horario FROM frequencias GROUP BY data_registro ORDER BY data_registro DESC");
$historico = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frequência // 2D</title>
    <link rel="stylesheet" href="STYLEF.css">
</head>
<body>
    <header>
        <button onclick="window.history.back()">Voltar</button>
        <div id="tools-freq">
            <h1 id="Class-form-Title">Frequências</h1>
        </div>
    </header>

    <article>
        <?php if (empty($historico)): ?>
            <div id="Class-Form-freq">
                <div id="freq-Container">
                    <div class="freq-base">
                        <div class="freq-titulo">
                            <h1 style="font-size: 5vh;">Frequência dia: <?php echo date('d/m/Y'); ?></h1>  
                        </div>
                        <div class="freq-content">
                            <h3 class="freq-text">Status: Nenhum registro hoje ainda</h3>
                        </div>
                        <button class="enter-freq" onclick="window.location.href='Chamada.php'">Criar Frequência</button>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($historico as $registro): 
                $dataFormatada = date('d/m/Y', strtotime($registro['data_registro']));
                $horarioFormatado = date('H:i:s', strtotime($registro['ultimo_horario']));
            ?>
                <div id="Class-Form-freq" style="margin-bottom: 20px;">
                    <div id="freq-Container">
                        <div class="freq-base">
                            <div class="freq-titulo">
                                <h1 style="font-size: 5vh;">Frequência dia: <?php echo $dataFormatada; ?></h1>  
                            </div>
                            <div class="freq-content">
                                <h3 class="freq-text">
                                    Status: Atualizado neste dia às <?php echo $horarioFormatado; ?>
                                </h3>
                            </div>
                            <button class="enter-freq" onclick="window.location.href='Chamada.php?data=<?php echo $registro['data_registro']; ?>'">Ver / Editar Frequência</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </article>
</body>
</html>