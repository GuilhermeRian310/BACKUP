CREATE DATABASE IF NOT EXISTS sistema_chamada 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_general_ci;

USE sistema_chamada;

-- Aproveite para criar as tabelas necessárias:
CREATE TABLE IF NOT EXISTS alunos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero INT NOT NULL,
    nome VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS frequencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aluno_id INT,
    data_registro DATE NOT NULL,
    f1 VARCHAR(10), f2 VARCHAR(10), f3 VARCHAR(10),
    f4 VARCHAR(10), f5 VARCHAR(10), f6 VARCHAR(10),
    f7 VARCHAR(10), f8 VARCHAR(10), f9 VARCHAR(10),
    horario TIME NOT NULL,
    FOREIGN KEY (aluno_id) REFERENCES alunos(id) ON DELETE CASCADE
);