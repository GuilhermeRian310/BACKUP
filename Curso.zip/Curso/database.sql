create database sistema_chamada;
use sistema_chamada;

//tabela de alunos
create table alunos (
    id int auto_increment primary key,
    nome varchar(255) not null
);

//tabela de presença
create table presenca (
    id int auto_increment primary key,
    aluno_id int,
    data_chamada date not null,
    status enum('presente', 'ausente') not null,
    foreign key (aluno_id) references alunos(id)
);