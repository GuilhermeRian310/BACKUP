const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// conexão com o banco de dados
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'sua_senha',
    database: 'sua_database'
});

// rota de conectar os alunos
app.get('/alunos', (req, res) => {
    db.query('select * from alunos', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// rota para salvar a presença dos alunos
app.post('/presenca', (req, res) => {
    const { presenca, data } = req.body;
    const valores = presenca.map(p => [p.aluno_id, data, p.status]);
    const sql = 'insert into presenca (aluno_id, data_chamada, status) values?';
    db.query(sql, [valores], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Presença salva com sucesso!');
    });
});
app.listen(3000, () => console.log('Servidor rodando na porta 3000'));