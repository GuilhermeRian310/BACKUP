<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chamada</title>
    <link rel="stylesheet" href="style1.css">
    <script src="node1.js" defer></script>
</head>
<body>
    <h2>Lista de chamada - data: <span id="data-atual"></span></h2>
    <form id="form-chamada">
        <table border="1">
            <thead>
                <tr>
                    <th>Presente</th>
                    <th>Nome do Aluno</th>
                </tr>
            </thead>
            <tbody id="Lista-alunos">
                <!-- A lista de alunos será preenchida aqui dinamicamente via js -->
            </tbody>
        </table>
        <br>
        <button type="submit">Salvar Chamada</button>
    </form>
    <script>
        // Código JavaScript para definir a data atual
        const hoje = new Date().toISOString().split('T')[0]; // Obtém a data atual no formato YYYY-MM-DD
        document.getElementById('data-atual').innerText = hoje;

        //buscar os alunos na backend e renderizar a tabela
        async function carregaralunos() {
            const response = await fetch('http://localhost:3000/alunos');
            const alunos = await response.json();
            const tbody = document.getElementById('Lista-alunos');

            alunos.forEach(aluno => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>
                        <input type="radio" name="aluno_${aluno.id}" value="presente" checked> Presente
                        <input type="radio" name="aluno_${aluno.id}" value="ausente"> Ausente
                    </td>
                    <td>${aluno.nome}</td> <!-- Faltava esta linha -->
                `;
                tr.dataset.id = aluno.id;
                tbody.appendChild(tr);
            });
        }
        // Enviar a chamada para o banco de dados
        document.getElementById('form-chamada').addEventListener('submit', async (e) => {
            e.preventDefault();
            const linhas = document.querySelectorAll('#Lista-alunos tr');
            const chamada = [];

            linhas.forEach(linha => {
                const id = linha.dataset.id;
                const status = linha.querySelector(`input[name="aluno_${id}"]:checked`).value;
                chamada.push({ id, status });
            });
            const response = await fetch('http://localhost:3000/presenca', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ data: hoje, chamada })
            });
            if (response.ok) {
                alert('Chamada salva com sucesso!');
            } else {
                alert('Erro ao salvar a chamada.');
            }
        });

    </script>

    <footer>
        <button id="add-btn" type="button">+ | Colocar aluno</button>
    </footer>
</body>
</html>