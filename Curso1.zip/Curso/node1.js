// Código para rodar no NAVEGADOR (Frontend)

const hoje = new Date().toISOString().split('T')[0];
document.getElementById('data-atual').innerText = hoje;

// Buscar os alunos no backend e renderizar a tabela
async function carregaralunos() {
    const response = await fetch('http://localhost:3000/alunos');
    const alunos = await response.json();
    const tbody = document.getElementById('Lista-alunos');

    alunos.forEach(aluno => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <input type="radio" name="aluno_${aluno.id}" value="presente" checked> Presente
                <input type="radio" name="aluno_${aluno.id}" value="ausente"> Ausente
            </td>
            <td>${aluno.nome}</td>
        `;
        tr.dataset.id = aluno.id;
        tbody.appendChild(tr);
    });
}

// Executa a função ao carregar a página
carregaralunos();

// Enviar a chamada para o banco de dados
document.getElementById('form-chamada').addEventListener('submit', async (e) => {
    e.preventDefault();
    const linhas = document.querySelectorAll('#Lista-alunos tr');
    const chamada = [];

    linhas.forEach(linha => {
        const id = linha.dataset.id;
        const status = linha.querySelector(`input[name="aluno_${id}"]:checked`).value;
        // Ajustado para 'aluno_id' para bater com o seu backend
        chamada.push({ aluno_id: id, status: status }); 
    });

    const response = await fetch('http://localhost:3000/presenca', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        // Ajustado de 'chamada' para 'presenca' para bater com o seu req.body do backend
        body: JSON.stringify({ data: hoje, presenca: chamada }) 
    });

    if (response.ok) {
        alert('Chamada salva com sucesso!');
    } else {
        alert('Erro ao salvar a chamada.');
    }
});

// Botão de adicionar aluno temporário na tabela
document.getElementById('add-btn').addEventListener('click', () => {
    const nomeAluno = prompt("Digite o nome do novo aluno:");
    //buscar os alunos na backend e renderizar a tabela
    async function carregaralunos() {
        const response = await fetch('http://localhost:3000/alunos');
        const alunos = await response.json();
        const tbody = document.getElementById('Lista-alunos');

        alunos.forEach(aluno => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>
                    <input type="radio" name="aluno_${aluno.id}" value="presente" checked> Presente
                    <input type="radio" name="aluno_${aluno.id}" value="ausente"> Ausente
                </td>
                <td>${aluno.nome}</td> <!-- Faltava esta linha -->
            `;
            tr.dataset.id = aluno.id;
            tbody.appendChild(tr);
        });
    }
    // Enviar a chamada para o banco de dados
    document.getElementById('form-chamada').addEventListener('submit', async (e) => {
        e.preventDefault();
        const linhas = document.querySelectorAll('#Lista-alunos tr');
        const chamada = [];

        linhas.forEach(linha => {
            const id = linha.dataset.id;
            const status = linha.querySelector(`input[name="aluno_${id}"]:checked`).value;
            chamada.push({ id, status });
        });
        const response = await fetch('http://localhost:3000/presenca', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ data: hoje, chamada })
        });
        if (response.ok) {
            alert('Chamada salva com sucesso!');
        } else {
            alert('Erro ao salvar a chamada.');
        }
        if (!nomeAluno || nomeAluno.trim() === "") {
            alert("Nome inválido! Ação cancelada.");
            return;
        }
    });
    const tbody = document.getElementById('Lista-alunos');
    const tr = document.createElement('tr');
    
    const idTemporario = "novo_" + Date.now();
    tr.dataset.id = idTemporario;

    tr.innerHTML = `
        <td>
            <input type="radio" name="aluno_${idTemporario}" value="presente" checked> Presente
            <input type="radio" name="aluno_${idTemporario}" value="ausente"> Ausente
        </td>
        <td>${nomeAluno.trim()}</td>
    `;

    tbody.appendChild(tr);
});