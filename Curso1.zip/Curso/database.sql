CREATE DATABASE IF NOT EXISTS sistema_chamada2;
USE sistema_chamada2;


CREATE TABLE IF NOT EXISTS alunos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL
);


CREATE TABLE IF NOT EXISTS presenca (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aluno_id INT,
    data_chamada DATE NOT NULL,
    STATUS enum('presente', 'ausente') NOT NULL,
    FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);