// Código para rodar no NODE.JS (Backend - server.js)
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'sistema_chamada2'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Conectado ao banco de dados MySQL!');
});

// Rota para listar os alunos
app.get('/alunos', (req, res) => {
    db.query('SELECT * FROM alunos', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// Rota para salvar a presença dos alunos
app.post('/presenca', (req, res) => {
    const { presenca, data } = req.body;
    
    // Mapeia os dados recebidos do front para a estrutura do banco de dados
    const valores = presenca.map(p => [p.aluno_id, data, p.status]);
    const sql = 'INSERT INTO presenca (aluno_id, data_chamada, status) VALUES ?';
    
    db.query(sql, [valores], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Presença salva com sucesso!');
    });
});

app.listen(3000, () => console.log('Servidor rodando na porta 3000'));
