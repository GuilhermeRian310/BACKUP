<?php 
include 'conexao.php'; 
$hoje = date('Y-m-d');

// Consulta a última atualização com base na última inserção
$resLog = $conn->query("SELECT MAX(id) as ultimo FROM registro_presenca WHERE data_registro = '$hoje'");
$tem_dados = false;
if($resLog) {
    $row = $resLog->fetch_assoc();
    if($row['ultimo']) $tem_dados = true;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frequência // 2D</title>
    <link rel="stylesheet" href="STYLEF.css">
</head>
<body>
    <header>
        <button onclick="window.history.back()">Voltar</button>
        <div id="tools-freq">
            <h1 id="Class-form-Title">Frequências</h1>
        </div>
    </header>

    <article>
        <div id="Class-Form-freq">
            <div id="freq-Container">
                <div class="freq-base">
                    <div class="freq-titulo">
                        <h1 style="font-size: 5vh;">Frequência dia: <?php echo date('d/m/Y'); ?></h1>  
                    </div>
                    <div class="freq-content">
                        <h3 class="freq-text">
                            Status: <?php echo $tem_dados ? "Atualizado hoje às " . date('H:i:s') : "Nenhum registro hoje ainda"; ?>
                        </h3>
                    </div>
                    <button class="enter-freq" onclick="window.location.href='Chamada.php'">Ver / Editar Frequência</button>
                </div>
            </div>
        </div>
    </article>
</body>
</html>