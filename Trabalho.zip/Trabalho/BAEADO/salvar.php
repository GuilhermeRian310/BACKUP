<?php
// Ativa exibição de erros ocultos para ajudar no diagnóstico
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

include 'conexao.php';

// Captura a entrada bruta
$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!empty($data)) {
    $hoje = date('Y-m-d');
    
    // Executa operações limpando dados anteriores do dia
    $conn->query("DELETE FROM registro_presenca WHERE data_registro = '$hoje'");
    $conn->query("TRUNCATE TABLE alunos"); 

    foreach ($data as $item) {
        $numero = (int)$item['numero'];
        $nome = $conn->real_escape_string($item['nome']);
        
        $conn->query("INSERT INTO alunos (numero, nome) VALUES ($numero, '$nome')");
        $aluno_id = $conn->insert_id;

        foreach ($item['frequencias'] as $index => $status) {
            $conn->query("INSERT INTO registro_presenca (aluno_id, coluna_index, status, data_registro) 
                          VALUES ($aluno_id, $index, '$status', '$hoje')");
        }
    }
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Nenhum dado recebido ou JSON inválido."]);
}
exit;
?>
