<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classe : 2D</title>
    <link rel="stylesheet" href="STYLEF.css">
    <script src="7.js" defer></script>
</head>
<body>
    <header>
        <button onclick="window.history.back()">Voltar</button>
        <div id="tools">
            <h1 id="Class-form-Title">Chamada</h1>
            <h1><p style="font-size: 4vh; margin-top: 10vh;">Data : <strong class="data-atual"><?php echo date('d/m/Y'); ?></strong></p></h1>
        </div>
    </header>
    <nav>
        <div id="article-container">
            <button id="edit-button">EDITAR</button>
            <button id="add-button" style="font-size: 2.3vh;">ADICIONAR</button>
            <button id="freq-button" style="font-size: 2vh;" onclick="window.location.href='Frequencia.php'">FREQUÊNCIA</button>
            <button id="save-button">SALVAR</button>
        </div>
    </nav>
    <article>
        <div id="Class-Form-base">
            <div id="base-Form">
                <table border="7">
                    <thead>
                        <tr>
                            <th>Número</th>
                            <th id="nome">Nome</th>
                            <th colspan="9" id="freq">Frequencias</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- O PHP vai renderizar os dados existentes aqui se houver -->
                        <?php
                        $hoje = date('Y-m-d');
                        $resAlunos = $conn->query("SELECT * FROM alunos ORDER BY numero ASC");
                        while($aluno = $resAlunos->fetch_assoc()) {
                            echo "<tr class='alunos'>";
                            echo "<td class='num_cham'><input type='text' class='numero' value='{$aluno['numero']}' disabled></td>";
                            echo "<td class='nome'><input type='text' class='nome_com' value='{$aluno['nome']}' disabled></td>";
                            
                            // Busca presenças do aluno
                            $aluno_id = $aluno['id'];
                            $resFreq = $conn->query("SELECT * FROM registro_presenca WHERE aluno_id = $aluno_id AND data_registro = '$hoje' ORDER BY coluna_index ASC");
                            
                            $freqs = [];
                            while($f = $resFreq->fetch_assoc()) { $freqs[$f['coluna_index']] = $f['status']; }

                            for($i=0; $i<9; $i++) {
                                $status = isset($freqs[$i]) ? $freqs[$i] : 'nao';
                                $img = $status . '.png';
                                $color = '#7f3931';
                                if($status == 'sim') $color = '#317f3a';
                                if($status == 'just') $color = '#7f7831';

                                echo "<td class='frequencia'><button class='freq' style='background-color:$color;'><img src='$img' class='img-freq' alt='$status'></button></td>";
                            }
                            echo "<td><button class='btn-apagar'>X</button></td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </article>
</body>
</html>

<?php include 'conexao.php'; ?>