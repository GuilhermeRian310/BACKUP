// Procure pela função do save-button no seu 7.js e substitua por esta:
document.getElementById('save-button').addEventListener('click', function() {
    const payload = [];
    const linhas = document.querySelectorAll('tr.alunos');

    linhas.forEach(linha => {
        const numero = linha.querySelector('.numero').value;
        const nome = linha.querySelector('.nome_com').value;
        const frequencias = [];

        linha.querySelectorAll('.freq img').forEach(img => {
            if(img.src.includes('sim.png')) frequencias.push('sim');
            else if(img.src.includes('just.png')) frequencias.push('just');
            else frequencias.push('nao');
        });

        payload.push({ numero, nome, frequencias });
    });

    fetch('salvar.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(async res => {
        const textOutput = await res.text(); // Captura a resposta bruta primeiro
        try {
            return JSON.parse(textOutput); // Tenta converter para JSON
        } catch(err) {
            // Se falhar, exibe o erro exato do PHP no console do navegador
            console.error("Resposta corrompida do servidor:", textOutput);
            throw new Error("O servidor não enviou um JSON válido. Verifique o Console (F12).");
        }
    })
    .then(data => {
        if(data.status === 'success') {
            alert('Frequência salva com sucesso!');
        } else {
            alert('Erro: ' + data.message);
        }
    })
    .catch(err => {
        alert(err.message);
        console.error(err);
    });
});
